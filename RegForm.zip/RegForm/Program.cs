﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace RegForm
{
    class Program
    {
        private static Label lblFName, lblLName, lblUName, lblPin, lblerror;
        private static TextBox txtFName, txtLName, txtUName, txtPin;
        private static Button btnSubmit;
        static void Main(string[] args)
        {
            Form RegFormWin = new Form();
            //Window form
            RegFormWin.Text = "Registration Form";
            RegFormWin.StartPosition = FormStartPosition.CenterParent;
            RegFormWin.Size = new Size(300,240);

            //First Name
            lblFName = new Label();
            lblFName.Text = "First Name:";
            lblFName.Size = new Size(70, 25);
            lblFName.Location = new Point(20, 17);
            lblFName.Parent = RegFormWin;

            txtFName = new TextBox();
            txtFName.Size = new Size(150, 50);
            txtFName.Location = new Point(110, 15);
            txtFName.Parent = RegFormWin;

            //Last Name
            lblLName = new Label();
            lblLName.Text = "Last Name:";
            lblLName.Size = new Size(70, 25);
            lblLName.Location = new Point(20, 47);
            lblLName.Parent = RegFormWin;

            txtLName = new TextBox();
            txtLName.Size = new Size(150,50);
            txtLName.Location = new Point(110, 45);
            txtLName.Parent = RegFormWin;

            //Username
            lblUName = new Label();
            lblUName.Text = "Username:";
            lblUName.Size = new Size(70, 25);
            lblUName.Location = new Point(20, 77);
            lblUName.Parent = RegFormWin;

            txtUName = new TextBox();
            txtUName.Size = new Size(150, 50);
            txtUName.Location = new Point(110, 75);
            txtUName.Parent = RegFormWin;

            //Pin
            lblPin = new Label();
            lblPin.Text = "PIN:";
            lblPin.Size = new Size(70, 25);
            lblPin.Location = new Point(20, 107);
            lblPin.Parent = RegFormWin;

            txtPin = new TextBox();
            txtPin.Size = new Size(150, 50);
            txtPin.Location = new Point(110, 105);
            txtPin.MaxLength = 4;
            txtPin.PasswordChar = '*';
            txtPin.Parent = RegFormWin;

            //Submit Button
            btnSubmit = new Button();
            btnSubmit.Text = "SUBMIT";
            btnSubmit.Size = new Size(100, 35);
            btnSubmit.Location = new Point(20, 140);
            btnSubmit.Click += new EventHandler(btnSubmit_Click);
            btnSubmit.Parent = RegFormWin;

            //Error message
            lblerror = new Label();
            lblerror.Text = "Sample";
            lblerror.ForeColor = Color.Red;
            lblerror.Visible = false;
            lblerror.Size = new Size(300, 25);
            lblerror.Location = new Point(20, 180);
            lblerror.Parent = RegFormWin;

            RegFormWin.ShowDialog();
        }

        static void btnSubmit_Click(object sender, EventArgs e)
        {
            string fName = "", lName = "", uName = "", pin = "";
            bool error = false;

            //If empty string
            if (txtFName.Text.Trim() == "" || txtLName.Text.Trim() == "" || txtPin.Text.Trim() == "" || txtUName.Text.Trim() == "")
            {
                lblerror.Text = "Error: There is an empty field";
                lblerror.Visible = true;
                error = true;
            }
            else
            {
                if (txtPin.Text.All(char.IsDigit))
                {
                    if (txtPin.Text.Length == 4)
                    {
                        error = false;
                    }                        
                    else
                    {
                        lblerror.Text = "Error: Pin should have exactly 4 numbers";
                        lblerror.Visible = true;
                        error = true;
                    }                      
                }
                else
                {               
                    lblerror.Text = "Error: Pin should only contain numbers";
                    lblerror.Visible = true;
                    error = true;
                }

                if (!error)
                {
                    fName = txtFName.Text;
                    lName = txtLName.Text;
                    uName = txtUName.Text;
                    pin = txtPin.Text;

                    lblerror.Text = "Success!";
                    lblerror.ForeColor = Color.Green;
                    lblerror.Visible = true;
                }
            }

            //Print muna para macheck kung nagana lmao
            Console.WriteLine(fName);
            Console.WriteLine(lName);
            Console.WriteLine(uName);
            Console.WriteLine(pin);
        }
    }
}
